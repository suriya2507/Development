import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

// import custom validator to validate that password and confirm password fields match
import { MustMatch } from '../customvalidators/must-match.validator';

@Component({
  selector: 'form.component',
  templateUrl: './form.component.html',
})


export class FormComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  public httpClient;
  public bUrl;

  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string, private formBuild: FormBuilder)
  {
    this.httpClient = http;
    this.bUrl = baseUrl;
  }

  ngOnInit() {
    this.registerForm = this.formBuild.group({
      //title: ['', Validators.required],
      title: ['', Validators.nullValidator],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      // validates date format yyyy-mm-dd
      dob: ['', [Validators.required, Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required],
      acceptTerms: [false, Validators.requiredTrue]
    }, {
      validator: MustMatch('password', 'confirmPassword')
    });
  }

  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }

    var regData = JSON.stringify(this.registerForm.value, null, 4);

    this.httpClient.post(this.bUrl + 'registration', this.registerForm.value).subscribe(result => {
      this.submitted = result;
    }, error => console.error(error));

    // display form values on success
    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value, null, 4));
    
  }

  onReset() {
    this.submitted = false;
    this.registerForm.reset();
  }
}
